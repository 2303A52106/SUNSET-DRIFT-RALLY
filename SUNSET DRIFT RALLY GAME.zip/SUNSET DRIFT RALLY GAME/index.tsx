import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";

const Game = lazy(() => import("@/game/Game"));

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Coastline Rush — Sunset Arcade Racer" },
      {
        name: "description",
        content: "A 3D arcade racer on a sunset coast: drift, boost with nitro, chain skill combos and beat three AI rivals over three laps.",
      },
      { property: "og:title", content: "Coastline Rush — Sunset Arcade Racer" },
      {
        property: "og:description",
        content: "Drift, boost and chain skill combos on a sunset coastal circuit against three AI rivals.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <Suspense
      fallback={
        <div className="fixed inset-0 flex items-center justify-center bg-background font-hud text-2xl font-bold italic tracking-[0.4em] text-muted-foreground">
          LOADING CIRCUIT…
        </div>
      }
    >
      <Game />
    </Suspense>
  );
}
