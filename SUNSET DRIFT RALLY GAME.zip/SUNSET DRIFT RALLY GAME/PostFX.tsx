import { Bloom, EffectComposer, ToneMapping, Vignette } from "@react-three/postprocessing";
import { useFrame } from "@react-three/fiber";
import { BlendFunction, Effect, EffectAttribute, ToneMappingMode } from "postprocessing";
import { useEffect, useMemo } from "react";
import * as THREE from "three";
import { carSpeed } from "../sim/car";
import { clamp, damp } from "../sim/math";
import { player } from "../sim/world";
import { getRuntime } from "../runtime";

// Radial (zoom) blur toward the screen edges: a cheap speed motion-blur.
const RADIAL_FRAG = /* glsl */ `
uniform float strength;
void mainImage(const in vec4 inputColor, const in vec2 uv, out vec4 outputColor) {
  vec2 dir = uv - vec2(0.5);
  float amt = strength * smoothstep(0.12, 0.72, length(dir));
  vec4 acc = inputColor;
  for (int i = 1; i < 8; i++) {
    acc += texture2D(inputBuffer, uv - dir * amt * (float(i) / 7.0));
  }
  outputColor = acc / 8.0;
}`;

class RadialBlurEffect extends Effect {
  constructor() {
    super("RadialBlurEffect", RADIAL_FRAG, {
      blendFunction: BlendFunction.NORMAL,
      attributes: EffectAttribute.CONVOLUTION,
      uniforms: new Map([["strength", new THREE.Uniform(0)]]),
    });
  }
}

export function PostFX() {
  const radial = useMemo(() => new RadialBlurEffect(), []);
  useEffect(() => () => radial.dispose(), [radial]);
  useFrame((_, delta) => {
    const w = getRuntime().world;
    const c = player(w).car;
    const kph = carSpeed(c) * 3.6;
    const racing = w.phase === "racing";
    const target = racing ? clamp((kph - 120) / 180, 0, 1) * 0.05 + (c.nitroActive ? 0.06 : 0) : 0;
    const u = radial.uniforms.get("strength")!;
    u.value += (target - u.value) * damp(4, Math.min(delta, 0.05));
  });
  return (
    <EffectComposer multisampling={0} enableNormalPass={false}>
      <Bloom mipmapBlur intensity={0.85} luminanceThreshold={0.95} luminanceSmoothing={0.2} radius={0.72} />
      <primitive object={radial} />
      <ToneMapping mode={ToneMappingMode.ACES_FILMIC} />
      <Vignette offset={0.3} darkness={0.55} />
    </EffectComposer>
  );
}
