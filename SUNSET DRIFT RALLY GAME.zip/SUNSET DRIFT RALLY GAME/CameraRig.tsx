import { useFrame, useThree } from "@react-three/fiber";
import { useRef } from "react";
import * as THREE from "three";
import { carSpeed } from "../sim/car";
import { MS_TO_KPH } from "../sim/constants";
import { clamp, damp, wrapAngle } from "../sim/math";
import { player } from "../sim/world";
import { getRuntime } from "../runtime";
import { getWorldGeo } from "./worldGeo";

/** Shared per-frame camera info for the 2D overlay (speed lines, sun flare). */
export const camInfo = { sunX: 0.5, sunY: 0.3, sunVisible: false, speed01: 0, nitro: false, kph: 0, racing: false };

export const FOV_MIN = 60;
export const FOV_MAX = 85;

const _look = new THREE.Vector3();
const _sun = new THREE.Vector3();

export function CameraRig() {
  const { camera } = useThree();
  const st = useRef({ yaw: 0, init: false, t: 0, orbit: 0 });
  const geo = getWorldGeo();

  useFrame((_, delta) => {
    const dt = Math.min(delta, 0.05);
    const rt = getRuntime();
    const w = rt.world;
    const c = player(w).car;
    const cam = camera as THREE.PerspectiveCamera;
    const s = st.current;
    s.t += dt;
    const sp = carSpeed(c);
    const kph = sp * MS_TO_KPH;
    const speed01 = clamp(kph / 260, 0, 1);

    if (!s.init) {
      s.yaw = c.yaw;
      s.init = true;
    }

    if (w.phase === "menu" || w.phase === "finished") {
      // Slow cinematic orbit around the player's car
      s.orbit += dt * 0.18;
      const a = c.yaw + Math.PI * 0.8 + Math.sin(s.orbit) * 0.9;
      const dist = w.phase === "menu" ? 9 : 11;
      const target = new THREE.Vector3(c.x + Math.sin(a) * dist, 2.4, c.z + Math.cos(a) * dist);
      cam.position.lerp(target, w.phase === "menu" ? 1 : damp(2, dt));
      _look.set(c.x, 1.0, c.z);
      cam.lookAt(_look);
      cam.fov += (55 - cam.fov) * damp(3, dt);
      cam.updateProjectionMatrix();
      s.yaw = c.yaw;
    } else {
      // Chase cam: yaw lags the car and leans toward the direction of travel while drifting
      const velYaw = sp > 4 ? Math.atan2(c.vx, c.vz) : c.yaw;
      const targetYaw = c.forwardSpeed < -1 ? c.yaw : c.yaw + wrapAngle(velYaw - c.yaw) * 0.45;
      s.yaw += wrapAngle(targetYaw - s.yaw) * damp(4.2, dt);
      const dist = 7.6 + speed01 * 1.8;
      const height = 2.55 + speed01 * 0.35;
      const desiredX = c.x - Math.sin(s.yaw) * dist;
      const desiredZ = c.z - Math.cos(s.yaw) * dist;
      cam.position.x += (desiredX - cam.position.x) * damp(12, dt);
      cam.position.z += (desiredZ - cam.position.z) * damp(12, dt);
      cam.position.y += (height - cam.position.y) * damp(8, dt);

      // Velocity shake above 180 KPH + impact shake
      const over = clamp((kph - 180) / 120, 0, 1);
      const amp = over * 0.07 + rt.impact * 0.35 + (c.nitroActive ? 0.03 : 0);
      if (amp > 0) {
        cam.position.x += (Math.sin(s.t * 47.3) + Math.sin(s.t * 31.1)) * amp * 0.5;
        cam.position.y += Math.sin(s.t * 53.7) * amp * 0.5;
      }
      _look.set(c.x + Math.sin(s.yaw) * 5, 1.1, c.z + Math.cos(s.yaw) * 5);
      cam.lookAt(_look);

      // Dynamic FOV 60 -> 85 with speed (nitro pushes it to the top)
      const targetFov = clamp(FOV_MIN + speed01 * 20 + (c.nitroActive ? 7 : 0), FOV_MIN, FOV_MAX);
      cam.fov += (targetFov - cam.fov) * damp(c.nitroActive ? 5 : 3, dt);
      cam.updateProjectionMatrix();
    }

    // Sun screen position for the flare overlay
    _sun.set(cam.position.x + geo.sunDir[0] * 1000, cam.position.y + geo.sunDir[1] * 1000, cam.position.z + geo.sunDir[2] * 1000);
    _sun.project(cam);
    camInfo.sunVisible = _sun.z < 1 && Math.abs(_sun.x) < 1.3 && Math.abs(_sun.y) < 1.3;
    camInfo.sunX = (_sun.x + 1) / 2;
    camInfo.sunY = (1 - _sun.y) / 2;
    camInfo.speed01 = speed01;
    camInfo.nitro = c.nitroActive && w.phase === "racing";
    camInfo.kph = kph;
    camInfo.racing = w.phase === "racing";
  });
  return null;
}
