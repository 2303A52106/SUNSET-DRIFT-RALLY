import { useFrame, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { carSpeed, type CarState } from "../sim/car";
import { getRuntime } from "../runtime";
import { softDotTexture } from "./textures";

// Rear wheel & exhaust positions in car-local metres (x left+, z forward+), for a 4.5 m car
const REAR_WHEELS: [number, number][] = [
  [0.62, -1.5],
  [-0.62, -1.5],
];
const EXHAUSTS: [number, number][] = [
  [0.32, -2.35],
  [-0.32, -2.35],
];

function toWorld(c: CarState, lx: number, lz: number, out: THREE.Vector3, y = 0) {
  const s = Math.sin(c.yaw);
  const co = Math.cos(c.yaw);
  // local +x maps to (cos, -sin), local +z to (sin, cos)
  out.set(c.x + lx * co + lz * s, y, c.z - lx * s + lz * co);
  return out;
}

// ---------- Particles (CPU-simulated points) ----------
const VERT = /* glsl */ `
attribute float aSize;
attribute float aAlpha;
attribute vec3 aColor;
uniform float uScale;
varying float vAlpha;
varying vec3 vColor;
void main() {
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_Position = projectionMatrix * mv;
  gl_PointSize = min(aSize * uScale / max(0.1, -mv.z), 512.0);
  vAlpha = aAlpha;
  vColor = aColor;
}`;
const FRAG = /* glsl */ `
uniform sampler2D uMap;
varying float vAlpha;
varying vec3 vColor;
void main() {
  float a = texture2D(uMap, gl_PointCoord).a * vAlpha;
  if (a < 0.003) discard;
  gl_FragColor = vec4(min(vColor, vec3(8.0)), a);
}`;

class ParticlePool {
  count: number;
  pos: Float32Array;
  vel: Float32Array;
  age: Float32Array;
  life: Float32Array;
  size0: Float32Array;
  size1: Float32Array;
  sizes: Float32Array;
  alphas: Float32Array;
  colors: Float32Array;
  next = 0;
  geometry = new THREE.BufferGeometry();
  constructor(count: number) {
    this.count = count;
    this.pos = new Float32Array(count * 3);
    this.vel = new Float32Array(count * 3);
    this.age = new Float32Array(count).fill(1);
    this.life = new Float32Array(count).fill(1);
    this.size0 = new Float32Array(count);
    this.size1 = new Float32Array(count);
    this.sizes = new Float32Array(count);
    this.alphas = new Float32Array(count);
    this.colors = new Float32Array(count * 3);
    this.geometry.setAttribute("position", new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    this.geometry.setAttribute("aSize", new THREE.BufferAttribute(this.sizes, 1).setUsage(THREE.DynamicDrawUsage));
    this.geometry.setAttribute("aAlpha", new THREE.BufferAttribute(this.alphas, 1).setUsage(THREE.DynamicDrawUsage));
    this.geometry.setAttribute("aColor", new THREE.BufferAttribute(this.colors, 3).setUsage(THREE.DynamicDrawUsage));
  }
  emit(p: THREE.Vector3, vx: number, vy: number, vz: number, life: number, s0: number, s1: number) {
    const i = this.next;
    this.next = (this.next + 1) % this.count;
    this.pos.set([p.x, p.y, p.z], i * 3);
    this.vel.set([vx, vy, vz], i * 3);
    this.age[i] = 0;
    this.life[i] = life;
    this.size0[i] = s0;
    this.size1[i] = s1;
  }
  clear() {
    this.age.fill(1);
    this.life.fill(1);
    this.alphas.fill(0);
  }
  update(dt: number, drag: number, rise: number, shade: (t: number, i: number) => void) {
    const k = Math.exp(-drag * dt);
    const { age, life, vel, pos, sizes, size0, size1 } = this;
    for (let i = 0; i < this.count; i++) {
      const a = age[i]!;
      const l = life[i]!;
      if (a >= l) {
        this.alphas[i] = 0;
        continue;
      }
      age[i] = a + dt;
      const t = Math.min(1, (a + dt) / l);
      const j = i * 3;
      const vx = vel[j]! * k;
      const vy = vel[j + 1]! * k + rise * dt;
      const vz = vel[j + 2]! * k;
      vel[j] = vx;
      vel[j + 1] = vy;
      vel[j + 2] = vz;
      pos[j] = pos[j]! + vx * dt;
      pos[j + 1] = pos[j + 1]! + vy * dt;
      pos[j + 2] = pos[j + 2]! + vz * dt;
      sizes[i] = size0[i]! + (size1[i]! - size0[i]!) * t;
      shade(t, i);
    }
    for (const n of ["position", "aSize", "aAlpha", "aColor"]) (this.geometry.attributes[n] as THREE.BufferAttribute).needsUpdate = true;
  }
}

function makeMaterial(map: THREE.Texture, additive: boolean) {
  return new THREE.ShaderMaterial({
    vertexShader: VERT,
    fragmentShader: FRAG,
    uniforms: { uMap: { value: map }, uScale: { value: 600 } } as Record<string, THREE.IUniform>,
    transparent: true,
    depthWrite: false,
    blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
  });
}

const _v = new THREE.Vector3();

/** Dev toggles for isolating effects in screenshots. */
export const fxFlags = { smoke: true, skid: true };
if (import.meta.env.DEV && typeof window !== "undefined") (window as unknown as { __fx: typeof fxFlags }).__fx = fxFlags;

export function TireAndNitroFX() {
  const { size, camera } = useThree();
  const map = useMemo(() => softDotTexture(), []);
  const smoke = useMemo(() => new ParticlePool(700), []);
  const flames = useMemo(() => new ParticlePool(500), []);
  const smokeMat = useMemo(() => makeMaterial(map, false), [map]);
  const flameMat = useMemo(() => makeMaterial(map, true), [map]);
  const acc = useRef({ smoke: 0, flame: 0 });
  const gen = useRef(getRuntime().generation);
  const smokeRef = useRef<THREE.Points>(null);

  useEffect(
    () => () => {
      smoke.geometry.dispose();
      flames.geometry.dispose();
      smokeMat.dispose();
      flameMat.dispose();
      map.dispose();
    },
    [smoke, flames, smokeMat, flameMat, map],
  );

  useFrame((_, delta) => {
    const dt = Math.min(delta, 0.05);
    const rt = getRuntime();
    if (gen.current !== rt.generation) {
      gen.current = rt.generation;
      smoke.clear();
      flames.clear();
    }
    const cam = camera as THREE.PerspectiveCamera;
    const scale = size.height / (2 * Math.tan((cam.fov * Math.PI) / 360));
    smokeMat.uniforms["uScale"]!.value = scale;
    flameMat.uniforms["uScale"]!.value = scale;

    for (const r of rt.world.racers) {
      const c = r.car;
      const sp = carSpeed(c);
      const slip = Math.abs(c.slip);
      const skidding = slip > 0.16 && sp > 9;
      if (skidding) {
        const rate = (40 + slip * 120) * (r.isPlayer ? 1 : 0.6);
        acc.current.smoke += rate * dt;
        while (acc.current.smoke >= 1) {
          acc.current.smoke -= 1;
          for (const [lx, lz] of REAR_WHEELS) {
            toWorld(c, lx + (Math.random() - 0.5) * 0.8, lz + (Math.random() - 0.5) * 0.8, _v, 0.6);
            smoke.emit(
              _v,
              c.vx * 0.12 + (Math.random() - 0.5) * 4,
              0.9 + Math.random() * 1.4,
              c.vz * 0.12 + (Math.random() - 0.5) * 4,
              1.2 + Math.random() * 0.9,
              0.7 + Math.random() * 0.5,
              3.2 + Math.random() * 1.8,
            );
          }
        }
      }
      if (c.nitroActive) {
        acc.current.flame += 110 * dt;
        const fx = Math.sin(c.yaw);
        const fz = Math.cos(c.yaw);
        while (acc.current.flame >= 1) {
          acc.current.flame -= 1;
          for (const [lx, lz] of EXHAUSTS) {
            toWorld(c, lx, lz, _v, 0.42);
            const back = 9 + Math.random() * 6;
            flames.emit(
              _v,
              c.vx * 0.85 - fx * back + (Math.random() - 0.5),
              (Math.random() - 0.3) * 0.8,
              c.vz * 0.85 - fz * back + (Math.random() - 0.5),
              0.16 + Math.random() * 0.14,
              0.9 + Math.random() * 0.3,
              0.25,
            );
          }
        }
      }
    }
    if (smokeRef.current) smokeRef.current.visible = fxFlags.smoke;
    smoke.update(dt, 1.4, 0.4, (t, i) => {
      const fadeIn = Math.min(1, t * 3.5);
      smoke.alphas[i] = 0.32 * (1 - t) * fadeIn * fadeIn;
      const v = 0.92 + 0.08 * (1 - t);
      smoke.colors.set([v, v * 0.97, v * 0.95], i * 3);
    });
    flames.update(dt, 3, 0, (t, i) => {
      flames.alphas[i] = 1 - t;
      // white-blue core -> orange -> red
      const r = 3.2 - t * 0.8;
      const g = t < 0.3 ? 2.6 - t * 3 : 1.7 - t * 1.6;
      const b = t < 0.15 ? 3.0 : 0.5 * (1 - t);
      flames.colors.set([r, Math.max(0.1, g), b], i * 3);
    });
  });

  return (
    <>
      <points ref={smokeRef} geometry={smoke.geometry} material={smokeMat} frustumCulled={false} />
      <points geometry={flames.geometry} material={flameMat} frustumCulled={false} />
    </>
  );
}

// ---------- Skidmarks (ring buffer of flat quads) ----------
const MAX_MARKS = 3000;

export function Skidmarks() {
  const ref = useRef<THREE.InstancedMesh>(null);
  const geometry = useMemo(() => {
    const g = new THREE.PlaneGeometry(0.34, 1);
    g.rotateX(-Math.PI / 2);
    return g;
  }, []);
  const material = useMemo(
    () =>
      new THREE.MeshBasicMaterial({
        color: "#121014",
        polygonOffset: true,
        polygonOffsetFactor: -2,
        polygonOffsetUnits: -2,
      }),
    [],
  );
  const state = useRef({ next: 0, last: new Map<string, THREE.Vector3>(), gen: -1 });
  const m = useMemo(() => new THREE.Matrix4(), []);
  const q = useMemo(() => new THREE.Quaternion(), []);
  const sc = useMemo(() => new THREE.Vector3(), []);
  const mid = useMemo(() => new THREE.Vector3(), []);
  const up = useMemo(() => new THREE.Vector3(0, 1, 0), []);

  useEffect(() => {
    const mesh = ref.current;
    if (!mesh) return;
    m.makeScale(0, 0, 0);
    for (let i = 0; i < MAX_MARKS; i++) mesh.setMatrixAt(i, m);
    mesh.instanceMatrix.needsUpdate = true;
    return () => {
      geometry.dispose();
      material.dispose();
    };
  }, [geometry, material, m]);

  useFrame(() => {
    const mesh = ref.current;
    const rt = getRuntime();
    if (!mesh) return;
    const st = state.current;
    if (st.gen !== rt.generation) {
      st.gen = rt.generation;
      st.last.clear();
      m.makeScale(0, 0, 0);
      for (let i = 0; i < MAX_MARKS; i++) mesh.setMatrixAt(i, m);
      mesh.instanceMatrix.needsUpdate = true;
    }
    let dirty = false;
    for (const r of rt.world.racers) {
      const c = r.car;
      const skidding = Math.abs(c.slip) > 0.16 && carSpeed(c) > 8;
      REAR_WHEELS.forEach(([lx, lz], wi) => {
        const key = `${r.id}-${wi}`;
        if (!skidding) {
          st.last.delete(key);
          return;
        }
        const p = toWorld(c, lx, lz, new THREE.Vector3(), 0.03);
        const prev = st.last.get(key);
        if (!prev) {
          st.last.set(key, p);
          return;
        }
        const d = p.distanceTo(prev);
        if (d < 0.6) return;
        if (d > 6) {
          st.last.set(key, p);
          return;
        }
        mid.addVectors(p, prev).multiplyScalar(0.5);
        q.setFromAxisAngle(up, Math.atan2(p.x - prev.x, p.z - prev.z));
        m.compose(mid, q, sc.set(1, 1, d + 0.05));
        mesh.setMatrixAt(st.next, m);
        st.next = (st.next + 1) % MAX_MARKS;
        st.last.set(key, p);
        dirty = true;
      });
    }
    if (dirty) mesh.instanceMatrix.needsUpdate = true;
    mesh.visible = fxFlags.skid;
  });

  return <instancedMesh ref={ref} args={[geometry, material, MAX_MARKS]} frustumCulled={false} />;
}
