import { useMemo } from "react";
import * as THREE from "three";
import { TRACK } from "../sim/constants";
import type { Track } from "../sim/track";
import { sampleAt } from "../sim/track";
import { getRuntime } from "../runtime";
import { asphaltTexture, bannerTexture, barrierTexture, checkerTexture, curbTexture, signTexture } from "./textures";

interface Edge {
  lat: number;
  y: number;
}

/** Ribbon along the track between two (lateral, height) edges. */
function ribbon(track: Track, a: Edge, b: Edge, vLen: number, alongU = false) {
  const n = track.count + 1;
  const pos = new Float32Array(n * 2 * 3);
  const uv = new Float32Array(n * 2 * 2);
  for (let i = 0; i < n; i++) {
    const s = track.samples[i % track.count]!;
    const v = (i * track.ds) / vLen;
    pos.set([s.x + s.rx * a.lat, a.y, s.z + s.rz * a.lat], i * 6);
    pos.set([s.x + s.rx * b.lat, b.y, s.z + s.rz * b.lat], i * 6 + 3);
    if (alongU) uv.set([v, 0, v, 1], i * 4);
    else uv.set([0, v, 1, v], i * 4);
  }
  const idx: number[] = [];
  for (let i = 0; i < n - 1; i++) {
    const a0 = i * 2;
    const b0 = i * 2 + 1;
    const a1 = i * 2 + 2;
    const b1 = i * 2 + 3;
    idx.push(a0, b0, a1, b0, b1, a1);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  g.setAttribute("uv", new THREE.BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

export const NEON_LEFT = new THREE.Color("#22e4ff").multiplyScalar(2.6);
export const NEON_RIGHT = new THREE.Color("#ff2f8e").multiplyScalar(2.6);

export function TrackMeshes() {
  const track = getRuntime().world.track;
  const W = TRACK.WALL;
  const HW = TRACK.HALF_WIDTH;
  const m = useMemo(() => {
    const asphalt = asphaltTexture();
    const curb = curbTexture();
    const barrier = barrierTexture();
    return {
      road: ribbon(track, { lat: -HW, y: 0 }, { lat: HW, y: 0 }, 16),
      curbL: ribbon(track, { lat: -W, y: 0.01 }, { lat: -HW, y: 0.01 }, 8),
      curbR: ribbon(track, { lat: HW, y: 0.01 }, { lat: W, y: 0.01 }, 8),
      wallL: ribbon(track, { lat: -W, y: 0 }, { lat: -W, y: 1.05 }, 8, true),
      wallR: ribbon(track, { lat: W, y: 0 }, { lat: W, y: 1.05 }, 8, true),
      neonL: ribbon(track, { lat: -W + 0.03, y: 0.88 }, { lat: -W + 0.03, y: 1.04 }, 8, true),
      neonR: ribbon(track, { lat: W - 0.03, y: 0.88 }, { lat: W - 0.03, y: 1.04 }, 8, true),
      capL: ribbon(track, { lat: -W - 0.25, y: 1.06 }, { lat: -W + 0.1, y: 1.06 }, 8),
      capR: ribbon(track, { lat: W - 0.1, y: 1.06 }, { lat: W + 0.25, y: 1.06 }, 8),
      asphalt,
      curb,
      barrier,
    };
  }, [track, HW, W]);

  return (
    <group>
      <mesh geometry={m.road} receiveShadow>
        <meshStandardMaterial map={m.asphalt} roughness={0.82} metalness={0.05} side={THREE.DoubleSide} />
      </mesh>
      <mesh geometry={m.curbL} receiveShadow>
        <meshStandardMaterial map={m.curb} roughness={0.7} side={THREE.DoubleSide} />
      </mesh>
      <mesh geometry={m.curbR} receiveShadow>
        <meshStandardMaterial map={m.curb} roughness={0.7} side={THREE.DoubleSide} />
      </mesh>
      <mesh geometry={m.wallL} castShadow receiveShadow>
        <meshStandardMaterial map={m.barrier} roughness={0.6} side={THREE.DoubleSide} />
      </mesh>
      <mesh geometry={m.wallR} castShadow receiveShadow>
        <meshStandardMaterial map={m.barrier} roughness={0.6} side={THREE.DoubleSide} />
      </mesh>
      <mesh geometry={m.neonL}>
        <meshBasicMaterial color={NEON_LEFT} toneMapped={false} side={THREE.DoubleSide} />
      </mesh>
      <mesh geometry={m.neonR}>
        <meshBasicMaterial color={NEON_RIGHT} toneMapped={false} side={THREE.DoubleSide} />
      </mesh>
      <mesh geometry={m.capL}>
        <meshBasicMaterial color={NEON_LEFT} toneMapped={false} side={THREE.DoubleSide} />
      </mesh>
      <mesh geometry={m.capR}>
        <meshBasicMaterial color={NEON_RIGHT} toneMapped={false} side={THREE.DoubleSide} />
      </mesh>
      <FinishArch track={track} />
      {getRuntime().world.traps.map((s, i) => (
        <SpeedTrap key={i} track={track} s={s} />
      ))}
    </group>
  );
}

function frameAt(track: Track, s: number) {
  const sm = sampleAt(track, s);
  return { position: [sm.x, 0, sm.z] as [number, number, number], yaw: Math.atan2(sm.tx, sm.tz) };
}

function FinishArch({ track }: { track: Track }) {
  const { position, yaw } = frameAt(track, 0);
  const span = TRACK.WALL + 1.4;
  const tex = useMemo(
    () => ({
      front: bannerTexture("FINISH", "COASTLINE RUSH · SUNSET CIRCUIT", "#ff4f9a"),
      checker: checkerTexture(18, 2),
    }),
    [],
  );
  const pink = useMemo(() => new THREE.Color("#ff2f8e").multiplyScalar(3), []);
  const warm = useMemo(() => new THREE.Color("#ffd28a").multiplyScalar(2.4), []);
  return (
    <group position={position} rotation-y={yaw}>
      <mesh position={[0, 0.02, 0]} rotation-x={-Math.PI / 2} receiveShadow>
        <planeGeometry args={[TRACK.HALF_WIDTH * 2, 2.6]} />
        <meshStandardMaterial map={tex.checker} roughness={0.8} />
      </mesh>
      {[-1, 1].map((side) => (
        <group key={side} position={[side * span, 0, 0]}>
          <mesh position={[0, 5.5, 0]} castShadow>
            <boxGeometry args={[1.8, 11, 1.8]} />
            <meshStandardMaterial color="#1c1830" roughness={0.4} metalness={0.6} />
          </mesh>
          <mesh position={[-side * 0.92, 5.5, 0]}>
            <boxGeometry args={[0.08, 10.4, 0.5]} />
            <meshBasicMaterial color={pink} toneMapped={false} />
          </mesh>
        </group>
      ))}
      <mesh position={[0, 10.2, 0]} castShadow>
        <boxGeometry args={[span * 2 + 1.8, 2.6, 1.4]} />
        <meshStandardMaterial color="#181428" roughness={0.4} metalness={0.5} />
      </mesh>
      <mesh position={[0, 10.2, -0.72]} rotation-y={Math.PI}>
        <planeGeometry args={[span * 2 + 1.4, 2.3]} />
        <meshBasicMaterial map={tex.front} toneMapped={false} />
      </mesh>
      <mesh position={[0, 10.2, 0.72]}>
        <planeGeometry args={[span * 2 + 1.4, 2.3]} />
        <meshBasicMaterial map={tex.front} toneMapped={false} />
      </mesh>
      <mesh position={[0, 8.82, 0]}>
        <boxGeometry args={[span * 2, 0.12, 0.9]} />
        <meshBasicMaterial color={warm} toneMapped={false} />
      </mesh>
    </group>
  );
}

function SpeedTrap({ track, s }: { track: Track; s: number }) {
  const { position, yaw } = frameAt(track, s);
  const span = TRACK.WALL + 0.8;
  const sign = useMemo(() => signTexture("SPEED TRAP", "#5ff3ff"), []);
  const cyan = useMemo(() => new THREE.Color("#22e4ff").multiplyScalar(2.4), []);
  return (
    <group position={position} rotation-y={yaw}>
      <mesh position={[0, 0.03, 0]} rotation-x={-Math.PI / 2}>
        <planeGeometry args={[TRACK.HALF_WIDTH * 2, 0.5]} />
        <meshBasicMaterial color={cyan} toneMapped={false} transparent opacity={0.7} />
      </mesh>
      {[-1, 1].map((side) => (
        <mesh key={side} position={[side * span, 3.8, 0]} castShadow>
          <boxGeometry args={[0.5, 7.6, 0.5]} />
          <meshStandardMaterial color="#20283a" metalness={0.6} roughness={0.35} />
        </mesh>
      ))}
      <mesh position={[0, 7.4, 0]}>
        <boxGeometry args={[span * 2 + 0.5, 0.35, 0.35]} />
        <meshBasicMaterial color={cyan} toneMapped={false} />
      </mesh>
      <mesh position={[0, 8.6, -0.05]} rotation-y={Math.PI}>
        <planeGeometry args={[10, 1.9]} />
        <meshBasicMaterial map={sign} toneMapped={false} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
}
