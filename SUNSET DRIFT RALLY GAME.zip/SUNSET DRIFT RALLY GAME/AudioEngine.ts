// Procedural Web Audio engine — every sound is synthesized, no audio files.
// Graph: sources -> bus gains -> master -> compressor (limiter) -> analyser -> destination

export interface EngineFrame {
  rpm: number;
  throttle: number;
  speed: number; // m/s
  slip: number; // |rad|
  skidding: boolean;
  nitro: boolean;
}

export class AudioEngine {
  ctx: AudioContext | null = null;
  private master!: GainNode;
  private sfx!: GainNode;
  private engineBus!: GainNode;
  analyser!: AnalyserNode;
  private oscA!: OscillatorNode;
  private oscB!: OscillatorNode;
  private oscSub!: OscillatorNode;
  private engineFilter!: BiquadFilterNode;
  private engineGain!: GainNode;
  private screechGain!: GainNode;
  private screechFilter!: BiquadFilterNode;
  private screechTone!: OscillatorNode;
  private screechToneGain!: GainNode;
  private boostGain!: GainNode;
  private windGain!: GainNode;
  private windFilter!: BiquadFilterNode;
  private noiseBuffer!: AudioBuffer;
  private muted = false;
  private volume = 0.8;

  /** Must be called from a user gesture. */
  async init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") await this.ctx.resume();
      return;
    }
    const ctx = new AudioContext();
    this.ctx = ctx;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -10;
    comp.knee.value = 6;
    comp.ratio.value = 12;
    comp.attack.value = 0.003;
    comp.release.value = 0.15;
    this.analyser = ctx.createAnalyser();
    this.analyser.fftSize = 1024;
    this.master = ctx.createGain();
    this.master.gain.value = this.volume;
    this.master.connect(comp).connect(this.analyser).connect(ctx.destination);
    this.sfx = ctx.createGain();
    this.sfx.gain.value = 0.9;
    this.sfx.connect(this.master);
    this.engineBus = ctx.createGain();
    this.engineBus.gain.value = 0.55;
    this.engineBus.connect(this.master);

    // White noise buffer (2 s)
    this.noiseBuffer = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const d = this.noiseBuffer.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;

    // --- Engine: two detuned saws + square sub through a drive + lowpass
    this.oscA = ctx.createOscillator();
    this.oscA.type = "sawtooth";
    this.oscB = ctx.createOscillator();
    this.oscB.type = "sawtooth";
    this.oscB.detune.value = 9;
    this.oscSub = ctx.createOscillator();
    this.oscSub.type = "square";
    const subGain = ctx.createGain();
    subGain.gain.value = 0.45;
    const shaper = ctx.createWaveShaper();
    shaper.curve = makeDrive(3.2);
    this.engineFilter = ctx.createBiquadFilter();
    this.engineFilter.type = "lowpass";
    this.engineFilter.Q.value = 3;
    this.engineGain = ctx.createGain();
    this.engineGain.gain.value = 0;
    const mix = ctx.createGain();
    mix.gain.value = 0.32;
    this.oscA.connect(mix);
    this.oscB.connect(mix);
    this.oscSub.connect(subGain).connect(mix);
    mix.connect(shaper).connect(this.engineFilter).connect(this.engineGain).connect(this.engineBus);
    this.oscA.start();
    this.oscB.start();
    this.oscSub.start();

    // --- Tire screech: band-passed noise + wobbling tone
    const screechNoise = this.loopNoise();
    this.screechFilter = ctx.createBiquadFilter();
    this.screechFilter.type = "bandpass";
    this.screechFilter.frequency.value = 2600;
    this.screechFilter.Q.value = 9;
    this.screechGain = ctx.createGain();
    this.screechGain.gain.value = 0;
    screechNoise.connect(this.screechFilter).connect(this.screechGain).connect(this.sfx);
    this.screechTone = ctx.createOscillator();
    this.screechTone.type = "triangle";
    this.screechTone.frequency.value = 1150;
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 13;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 70;
    lfo.connect(lfoGain).connect(this.screechTone.frequency);
    this.screechToneGain = ctx.createGain();
    this.screechToneGain.gain.value = 0;
    this.screechTone.connect(this.screechToneGain).connect(this.sfx);
    this.screechTone.start();
    lfo.start();

    // --- Boost rumble (held): low sine + lowpassed noise
    const rumble = ctx.createOscillator();
    rumble.type = "sine";
    rumble.frequency.value = 48;
    const rumbleNoise = this.loopNoise();
    const rumbleLp = ctx.createBiquadFilter();
    rumbleLp.type = "lowpass";
    rumbleLp.frequency.value = 420;
    this.boostGain = ctx.createGain();
    this.boostGain.gain.value = 0;
    rumble.connect(this.boostGain);
    rumbleNoise.connect(rumbleLp).connect(this.boostGain);
    this.boostGain.connect(this.sfx);
    rumble.start();

    // --- Wind rush with speed
    const wind = this.loopNoise();
    this.windFilter = ctx.createBiquadFilter();
    this.windFilter.type = "bandpass";
    this.windFilter.Q.value = 0.6;
    this.windGain = ctx.createGain();
    this.windGain.gain.value = 0;
    wind.connect(this.windFilter).connect(this.windGain).connect(this.sfx);

    this.applyMute();
  }

  private loopNoise() {
    const ctx = this.ctx!;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.loop = true;
    src.start(0, Math.random() * 1.5);
    return src;
  }

  setMuted(m: boolean) {
    this.muted = m;
    this.applyMute();
  }

  private applyMute() {
    if (!this.ctx) return;
    this.master.gain.setTargetAtTime(this.muted ? 0 : this.volume, this.ctx.currentTime, 0.05);
  }

  suspend() {
    void this.ctx?.suspend();
  }
  resume() {
    void this.ctx?.resume();
  }

  /** Per-frame continuous parameters. */
  update(f: EngineFrame) {
    const ctx = this.ctx;
    if (!ctx || ctx.state !== "running") return;
    const t = ctx.currentTime;
    const tc = 0.04;
    const nitroPitch = f.nitro ? 1.16 : 1;
    // ~55 Hz at idle up to ~270 Hz at the redline
    const base = (25 + (f.rpm / 60) * 1.9) * nitroPitch;
    this.oscA.frequency.setTargetAtTime(base, t, tc);
    this.oscB.frequency.setTargetAtTime(base * 1.5, t, tc);
    this.oscSub.frequency.setTargetAtTime(base * 0.5, t, tc);
    const load = 0.35 + f.throttle * 0.65;
    this.engineFilter.frequency.setTargetAtTime(300 + (f.rpm / 7800) * 2600 * load + (f.nitro ? 900 : 0), t, tc);
    this.engineGain.gain.setTargetAtTime(0.32 + load * 0.38 + (f.nitro ? 0.12 : 0), t, tc);

    const screech = f.skidding ? Math.min(1, Math.max(0, (f.slip - 0.12) * 2.2)) * Math.min(1, f.speed / 18) : 0;
    this.screechGain.gain.setTargetAtTime(screech * 0.55, t, 0.05);
    this.screechToneGain.gain.setTargetAtTime(screech * 0.07, t, 0.05);
    this.screechFilter.frequency.setTargetAtTime(2200 + f.slip * 900, t, 0.1);
    this.screechTone.frequency.setTargetAtTime(1000 + f.slip * 300, t, 0.1);

    this.boostGain.gain.setTargetAtTime(f.nitro ? 0.42 : 0, t, f.nitro ? 0.03 : 0.2);
    const w = Math.min(1, f.speed / 85);
    this.windGain.gain.setTargetAtTime(w * w * 0.28, t, 0.1);
    this.windFilter.frequency.setTargetAtTime(400 + w * 1600, t, 0.1);
  }

  /** Bass-heavy boost hit: pitch-dropping sine thump + whoosh. */
  boost() {
    const ctx = this.ctx;
    if (!ctx) return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    o.type = "sine";
    o.frequency.setValueAtTime(150, t);
    o.frequency.exponentialRampToValueAtTime(38, t + 0.45);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(1.1, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.7);
    o.connect(g).connect(this.sfx);
    o.start(t);
    o.stop(t + 0.75);
    const n = ctx.createBufferSource();
    n.buffer = this.noiseBuffer;
    const f = ctx.createBiquadFilter();
    f.type = "bandpass";
    f.Q.value = 1.2;
    f.frequency.setValueAtTime(300, t);
    f.frequency.exponentialRampToValueAtTime(3200, t + 0.5);
    const ng = ctx.createGain();
    ng.gain.setValueAtTime(0.0001, t);
    ng.gain.exponentialRampToValueAtTime(0.5, t + 0.08);
    ng.gain.exponentialRampToValueAtTime(0.0001, t + 0.6);
    n.connect(f).connect(ng).connect(this.sfx);
    n.start(t);
    n.stop(t + 0.65);
  }

  impact(strength: number) {
    const ctx = this.ctx;
    if (!ctx) return;
    const t = ctx.currentTime;
    const v = Math.min(1, strength / 15);
    const n = ctx.createBufferSource();
    n.buffer = this.noiseBuffer;
    const f = ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = 900 + v * 1500;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.25 + v * 0.6, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.25);
    n.connect(f).connect(g).connect(this.sfx);
    n.start(t, Math.random());
    n.stop(t + 0.3);
    const o = ctx.createOscillator();
    o.frequency.setValueAtTime(90, t);
    o.frequency.exponentialRampToValueAtTime(40, t + 0.2);
    const og = ctx.createGain();
    og.gain.setValueAtTime(0.4 * v + 0.1, t);
    og.gain.exponentialRampToValueAtTime(0.0001, t + 0.25);
    o.connect(og).connect(this.sfx);
    o.start(t);
    o.stop(t + 0.3);
  }

  beep(high: boolean) {
    this.tone(high ? 880 : 440, high ? 0.6 : 0.22, "square", 0.18);
  }

  chime(level: number) {
    const ctx = this.ctx;
    if (!ctx) return;
    const root = 660 + Math.min(4, level) * 60;
    this.tone(root, 0.12, "triangle", 0.12);
    setTimeout(() => this.tone(root * 1.5, 0.18, "triangle", 0.1), 70);
  }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number) {
    const ctx = this.ctx;
    if (!ctx) return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.value = freq;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(this.sfx);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  /** Peak/RMS of the master output, for scripted level checks. */
  levels() {
    if (!this.ctx) return null;
    const buf = new Float32Array(this.analyser.fftSize);
    this.analyser.getFloatTimeDomainData(buf);
    let peak = 0;
    let sum = 0;
    for (const v of buf) {
      peak = Math.max(peak, Math.abs(v));
      sum += v * v;
    }
    return { peak, rms: Math.sqrt(sum / buf.length), state: this.ctx.state };
  }
}

function makeDrive(k: number) {
  const n = 1024;
  const curve = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const x = (i / (n - 1)) * 2 - 1;
    curve[i] = Math.tanh(k * x) / Math.tanh(k);
  }
  return curve;
}
