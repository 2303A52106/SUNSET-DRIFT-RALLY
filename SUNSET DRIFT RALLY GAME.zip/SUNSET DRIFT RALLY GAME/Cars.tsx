import { useGLTF } from "@react-three/drei";
import { useFrame } from "@react-three/fiber";
import { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import carRace from "@/assets/models/car-race.glb.asset.json";
import carFuture from "@/assets/models/car-race-future.glb.asset.json";
import carSedan from "@/assets/models/car-sedan-sports.glb.asset.json";
import carHatch from "@/assets/models/car-hatchback-sports.glb.asset.json";
import { carSpeed } from "../sim/car";
import { clamp, damp } from "../sim/math";
import { getRuntime } from "../runtime";

export const CAR_MODELS: string[] = [carRace.url, carFuture.url, carSedan.url, carHatch.url];
CAR_MODELS.forEach((u) => useGLTF.preload(u));

/** Target car length in metres; Kenney cars are ~2.6 units long. */
export const CAR_LENGTH = 4.5;

export interface CarDims {
  scale: number;
  rearZ: number;
  width: number;
  height: number;
  wheelRadius: number;
}

function normalize(root: THREE.Object3D): CarDims {
  const box = new THREE.Box3().setFromObject(root);
  const size = box.getSize(new THREE.Vector3());
  const scale = CAR_LENGTH / size.z;
  return { scale, rearZ: box.min.z * scale, width: size.x * scale, height: size.y * scale, wheelRadius: 0.3 * scale };
}

const _q = new THREE.Quaternion();
const _qs = new THREE.Quaternion();
const X = new THREE.Vector3(1, 0, 0);
const Y = new THREE.Vector3(0, 1, 0);

function CarModel({ racerId, url }: { racerId: number; url: string }) {
  const gltf = useGLTF(url);
  const root = useRef<THREE.Group>(null);
  const body = useRef<THREE.Group>(null);
  const flame = useRef<THREE.Mesh>(null);
  const brake = useRef<THREE.MeshBasicMaterial>(null);
  const brake2 = useRef<THREE.MeshBasicMaterial>(null);
  const { scene, dims } = useMemo(() => {
    const scene = gltf.scene.clone(true);
    const dims = normalize(scene);
    scene.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.castShadow = true;
        m.receiveShadow = true;
      }
    });
    return { scene, dims };
  }, [gltf]);
  const wheels = useRef<{ node: THREE.Object3D; q0: THREE.Quaternion; front: boolean }[]>([]);
  const spin = useRef(0);
  const roll = useRef(0);
  const pitch = useRef(0);

  useLayoutEffect(() => {
    const list: typeof wheels.current = [];
    scene.traverse((o) => {
      if (o.name.startsWith("wheel-")) list.push({ node: o, q0: o.quaternion.clone(), front: o.name.includes("front") });
    });
    wheels.current = list;
  }, [scene]);

  useFrame((state, delta) => {
    const r = getRuntime().world.racers[racerId];
    const g = root.current;
    if (!r || !g) return;
    const c = r.car;
    const dt = Math.min(delta, 0.05);
    g.position.set(c.x, 0, c.z);
    g.rotation.y = c.yaw;
    const sp = carSpeed(c);
    // body lean / pitch on a child so the physics transform stays clean
    const targetRoll = clamp(c.yawRate * sp * 0.0035, -0.09, 0.09);
    const targetPitch = clamp(-c.accel * 0.0016, -0.045, 0.045);
    roll.current += (targetRoll - roll.current) * damp(6, dt);
    pitch.current += (targetPitch - pitch.current) * damp(6, dt);
    if (body.current) {
      body.current.rotation.z = roll.current;
      body.current.rotation.x = pitch.current;
    }
    spin.current += (c.forwardSpeed * dt) / dims.wheelRadius;
    for (const w of wheels.current) {
      _qs.setFromAxisAngle(X, spin.current);
      _q.setFromAxisAngle(Y, w.front ? -c.steer * 0.45 : 0);
      w.node.quaternion.copy(_q).multiply(_qs).multiply(w.q0);
    }
    if (flame.current) {
      flame.current.visible = c.nitroActive;
      const f = 0.8 + Math.sin(state.clock.elapsedTime * 60) * 0.15 + Math.random() * 0.15;
      flame.current.scale.set(f, f * (1.2 + Math.random() * 0.4), f);
    }
    const glow = c.brake > 0 || c.forwardSpeed < -0.5 ? 2.2 : 0.6;
    for (const b of [brake.current, brake2.current]) b?.color.copy(BRAKE_RED).multiplyScalar(glow);
  });

  const flameColor = useMemo(() => new THREE.Color("#7fd2ff").multiplyScalar(3), []);
  return (
    <group ref={root}>
      <group ref={body}>
        <primitive object={scene} scale={dims.scale} />
        {/* tail lights */}
        {[-1, 1].map((side) => (
          <mesh key={side} position={[side * dims.width * 0.3, dims.height * 0.42, dims.rearZ + 0.03]}>
            <boxGeometry args={[dims.width * 0.16, 0.09, 0.05]} />
            <meshBasicMaterial ref={side === 1 ? brake : brake2} toneMapped={false} />
          </mesh>
        ))}
        <mesh ref={flame} position={[0, 0.42, dims.rearZ - 0.55]} rotation-x={-Math.PI / 2} visible={false}>
          <coneGeometry args={[0.2, 1.1, 10, 1, true]} />
          <meshBasicMaterial color={flameColor} toneMapped={false} transparent opacity={0.85} blending={THREE.AdditiveBlending} depthWrite={false} />
        </mesh>
      </group>
    </group>
  );
}
const BRAKE_RED = new THREE.Color("#ff1020");

export function Cars() {
  const racers = getRuntime().world.racers;
  return (
    <>
      {racers.map((r) => (
        <CarModel key={r.id} racerId={r.id} url={CAR_MODELS[r.model % CAR_MODELS.length]!} />
      ))}
    </>
  );
}
