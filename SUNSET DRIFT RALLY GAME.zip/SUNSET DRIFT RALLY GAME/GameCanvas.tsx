import { Canvas, useFrame } from "@react-three/fiber";
import { Suspense, useEffect, useRef, useState } from "react";
import { getRuntime } from "../runtime";
import { CameraRig } from "./CameraRig";
import { Cars } from "./Cars";
import { Skidmarks, TireAndNitroFX } from "./Effects";
import { FOG_COLOR, Lighting, Ocean, SkyAndSun, Terrain } from "./Landscape";
import { PostFX } from "./PostFX";
import { TrackMeshes } from "./TrackMeshes";
import { Vegetation } from "./Vegetation";

/** The single stepper: advances input, simulation, events and audio before anything draws. */
function Stepper() {
  useFrame((_, delta) => getRuntime().frame(delta), -10);
  return null;
}

/** Flags the wrapper once a few frames with the cars loaded have rendered. */
function ReadySignal({ onReady }: { onReady: () => void }) {
  const frames = useRef(0);
  useFrame(() => {
    frames.current++;
    if (frames.current === 3) onReady();
  });
  return null;
}

export function GameCanvas() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    getRuntime();
  }, []);
  return (
    <div className="fixed inset-0" data-scene-ready={ready ? "true" : undefined}>
      <Canvas
        shadows
        dpr={[1, 1.75]}
        gl={{ antialias: true, powerPreference: "high-performance", stencil: false }}
        camera={{ fov: 60, near: 0.3, far: 6000, position: [0, 4, -10] }}
      >
        <color attach="background" args={[FOG_COLOR]} />
        <fog attach="fog" args={[FOG_COLOR, 220, 1700]} />
        <Stepper />
        <SkyAndSun />
        <Lighting />
        <Terrain />
        <Ocean />
        <TrackMeshes />
        <Skidmarks />
        <TireAndNitroFX />
        <Suspense fallback={null}>
          <Cars />
          <ReadySignal onReady={() => setReady(true)} />
        </Suspense>
        <Suspense fallback={null}>
          <Vegetation />
        </Suspense>
        <CameraRig />
        <PostFX />
      </Canvas>
    </div>
  );
}
