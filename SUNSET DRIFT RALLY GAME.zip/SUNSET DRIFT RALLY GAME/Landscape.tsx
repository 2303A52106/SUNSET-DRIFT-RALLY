import { Environment, Lightformer, Sky } from "@react-three/drei";
import { useFrame } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { player } from "../sim/world";
import { mulberry32 } from "../sim/math";
import { COAST_X, SEA_LEVEL, terrainHeight } from "../sim/terrain";
import { getRuntime } from "../runtime";
import { sunTexture } from "./textures";
import { getWorldGeo } from "./worldGeo";

export const FOG_COLOR = "#e9a27f";

export function Lighting() {
  const geo = getWorldGeo();
  const light = useRef<THREE.DirectionalLight>(null);
  const target = useMemo(() => new THREE.Object3D(), []);
  const [sx, sy, sz] = geo.sunDir;
  useFrame(() => {
    const c = player(getRuntime().world).car;
    const l = light.current;
    if (!l) return;
    // Shadow-casting sun follows the player; keep it high enough for readable shadows
    l.position.set(c.x + sx * 160, 70, c.z + sz * 160);
    target.position.set(c.x, 0, c.z);
    target.updateMatrixWorld();
  });
  return (
    <>
      <hemisphereLight args={["#ffd2b8", "#40506e", 1.25]} />
      <ambientLight intensity={0.25} color="#ffe2cf" />
      <directionalLight
        ref={light}
        target={target}
        color="#ffb27a"
        intensity={3.1}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-bias={-0.0004}
        shadow-normalBias={0.04}
        shadow-camera-left={-70}
        shadow-camera-right={70}
        shadow-camera-top={70}
        shadow-camera-bottom={-70}
        shadow-camera-near={1}
        shadow-camera-far={400}
      />
      <primitive object={target} />
      <Environment resolution={128} frames={1}>
        <Lightformer intensity={3} color="#ff9a5c" position={[-60, 6, 20]} rotation-y={Math.PI / 2} scale={[80, 12, 1]} />
        <Lightformer intensity={1.6} color="#ff6fa0" position={[0, 40, 0]} rotation-x={Math.PI / 2} scale={[60, 60, 1]} />
        <Lightformer intensity={0.9} color="#5b7bd6" position={[60, 10, 0]} rotation-y={-Math.PI / 2} scale={[80, 20, 1]} />
        <Lightformer intensity={0.6} color="#ffd9b0" position={[0, 8, -60]} scale={[80, 10, 1]} />
      </Environment>
    </>
  );
}

const SKY_VERT = /* glsl */ `
varying vec3 vDir;
void main() {
  vDir = position;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}`;
const SKY_FRAG = /* glsl */ `
uniform vec3 uSun;
uniform vec3 uTop;
uniform vec3 uMid;
uniform vec3 uLow;
uniform vec3 uHorizon;
uniform vec3 uGround;
varying vec3 vDir;
void main() {
  vec3 d = normalize(vDir);
  float h = d.y;
  float sd = max(dot(d, uSun), 0.0);
  // the sky warms up toward the sun side
  float sunSide = sd * sd;
  vec3 col = mix(uHorizon, uLow, smoothstep(0.0, 0.09, h));
  col = mix(col, uMid, smoothstep(0.07 + sunSide * 0.08, 0.32 + sunSide * 0.1, h));
  col = mix(col, uTop, smoothstep(0.3, 0.9, h));
  col = mix(col, uGround, smoothstep(0.0, -0.25, h));
  // thin streaky clouds near the horizon
  float band = smoothstep(0.03, 0.08, h) * (1.0 - smoothstep(0.12, 0.22, h));
  float streak = 0.5 + 0.5 * sin(atan(d.z, d.x) * 9.0 + h * 40.0) * sin(atan(d.z, d.x) * 23.0);
  col = mix(col, uMid * 1.25 + vec3(0.25, 0.05, 0.02) * sunSide * 3.0, band * streak * 0.35);
  // sun glow
  float g1 = sd * sd * sd * sd;
  float g2 = g1 * g1 * g1 * g1;
  col += vec3(1.0, 0.45, 0.18) * g1 * 0.55 + vec3(1.0, 0.8, 0.5) * g2 * g2 * 2.0;
  gl_FragColor = vec4(col, 1.0);
}`;

export function SkyAndSun() {
  const geo = getWorldGeo();
  const [sx, sy, sz] = geo.sunDir;
  const sunTex = useMemo(() => sunTexture(), []);
  const sun = useRef<THREE.Sprite>(null);
  const dome = useRef<THREE.Mesh>(null);
  const skyMat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        vertexShader: SKY_VERT,
        fragmentShader: SKY_FRAG,
        side: THREE.BackSide,
        depthWrite: false,
        fog: false,
        uniforms: {
          uSun: { value: new THREE.Vector3(sx, sy, sz) },
          uTop: { value: new THREE.Color("#241347") },
          uMid: { value: new THREE.Color("#c04a86") },
          uLow: { value: new THREE.Color("#ff7c4c") },
          uHorizon: { value: new THREE.Color(FOG_COLOR) },
          uGround: { value: new THREE.Color("#7a4a5a") },
        },
      }),
    [sx, sy, sz],
  );
  useFrame(({ camera }) => {
    // Sky dome and sun disc follow the camera (infinitely far)
    dome.current?.position.copy(camera.position);
    sun.current?.position.set(camera.position.x + sx * 1500, camera.position.y + sy * 1500, camera.position.z + sz * 1500);
  });
  const sunColor = useMemo(() => new THREE.Color("#ffd7a0").multiplyScalar(3), []);
  return (
    <>
      <mesh ref={dome} material={skyMat} renderOrder={-2} frustumCulled={false}>
        <sphereGeometry args={[2500, 48, 24]} />
      </mesh>
      <sprite ref={sun} scale={[520, 520, 1]} renderOrder={-1}>
        <spriteMaterial map={sunTex} color={sunColor} blending={THREE.AdditiveBlending} depthWrite={false} fog={false} transparent />
      </sprite>
    </>
  );
}

export function Terrain() {
  const geo = getWorldGeo();
  const geometry = useMemo(() => {
    const size = 2800;
    const seg = 240;
    const g = new THREE.PlaneGeometry(size, size, seg, seg);
    g.rotateX(-Math.PI / 2);
    const pos = g.getAttribute("position") as THREE.BufferAttribute;
    const colors = new Float32Array(pos.count * 3);
    const rnd = mulberry32(99);
    const sand = new THREE.Color("#e7c79a");
    const wetSand = new THREE.Color("#b9966d");
    const grass = new THREE.Color("#6f8f3c");
    const dryGrass = new THREE.Color("#a59a4e");
    const rock = new THREE.Color("#8a6f66");
    const snow = new THREE.Color("#f7e6e0");
    const verge = new THREE.Color("#5d6b3a");
    const c = new THREE.Color();
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i) + 40;
      const z = pos.getZ(i);
      const h = terrainHeight(x, z, geo.field);
      pos.setXYZ(i, x, h, z);
      const d = geo.field.dist(x, z);
      const coastal = x < COAST_X + 110;
      if (h < SEA_LEVEL + 0.6) c.copy(wetSand);
      else if (coastal && h < 6) c.copy(sand);
      else if (h > 115) c.copy(snow);
      else if (h > 55) c.copy(rock).lerp(snow, Math.max(0, (h - 85) / 30));
      else c.copy(grass).lerp(dryGrass, rnd() * 0.6).lerp(rock, Math.max(0, (h - 30) / 25));
      if (d < 22 && !coastal) c.lerp(verge, 0.5);
      const j = 0.9 + rnd() * 0.18;
      colors.set([c.r * j, c.g * j, c.b * j], i * 3);
    }
    g.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    g.computeVertexNormals();
    return g;
  }, [geo]);
  return (
    <mesh geometry={geometry} receiveShadow>
      <meshStandardMaterial vertexColors flatShading roughness={0.95} metalness={0} />
    </mesh>
  );
}

export function Ocean() {
  const mat = useRef<THREE.MeshStandardMaterial>(null);
  const normal = useMemo(() => {
    const c = document.createElement("canvas");
    c.width = c.height = 256;
    const g = c.getContext("2d")!;
    const img = g.createImageData(256, 256);
    for (let y = 0; y < 256; y++)
      for (let x = 0; x < 256; x++) {
        const a = Math.sin((x / 256) * Math.PI * 8 + Math.sin((y / 256) * Math.PI * 4) * 1.5);
        const b = Math.sin((y / 256) * Math.PI * 10 + Math.cos((x / 256) * Math.PI * 6));
        const i = (y * 256 + x) * 4;
        img.data[i] = 128 + a * 40;
        img.data[i + 1] = 128 + b * 40;
        img.data[i + 2] = 255;
        img.data[i + 3] = 255;
      }
    g.putImageData(img, 0, 0);
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(220, 220);
    return t;
  }, []);
  useFrame((_, dt) => {
    normal.offset.x += dt * 0.004;
    normal.offset.y += dt * 0.0025;
  });
  return (
    <mesh rotation-x={-Math.PI / 2} position={[-1600, SEA_LEVEL, 0]}>
      <planeGeometry args={[7000, 7000]} />
      <meshStandardMaterial
        ref={mat}
        color="#1f5d7c"
        roughness={0.16}
        metalness={0.25}
        normalMap={normal}
        normalScale={new THREE.Vector2(0.35, 0.35)}
        envMapIntensity={1.4}
      />
    </mesh>
  );
}
