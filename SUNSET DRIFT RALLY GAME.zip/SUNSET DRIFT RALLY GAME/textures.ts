// Canvas-generated textures (no network). Called lazily on the client.
import * as THREE from "three";
import { mulberry32 } from "../sim/math";

function canvas(w: number, h: number) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  return [c, c.getContext("2d")!] as const;
}

function finish(c: HTMLCanvasElement, repeat = true, srgb = true) {
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  if (repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 8;
  t.needsUpdate = true;
  return t;
}

/** Asphalt with edge lines and a dashed center line. U across the road, V along it (one tile = 16 m). */
export function asphaltTexture() {
  const [c, g] = canvas(512, 1024);
  g.fillStyle = "#2b2b31";
  g.fillRect(0, 0, 512, 1024);
  const rnd = mulberry32(7);
  for (let i = 0; i < 26000; i++) {
    const v = 30 + rnd() * 40;
    g.fillStyle = `rgba(${v},${v},${v + 4},${0.35 + rnd() * 0.4})`;
    g.fillRect(rnd() * 512, rnd() * 1024, 1 + rnd() * 2, 1 + rnd() * 2);
  }
  // tyre-worn lanes
  for (const x of [150, 362]) {
    const grad = g.createLinearGradient(x - 50, 0, x + 50, 0);
    grad.addColorStop(0, "rgba(0,0,0,0)");
    grad.addColorStop(0.5, "rgba(10,10,14,0.35)");
    grad.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = grad;
    g.fillRect(x - 50, 0, 100, 1024);
  }
  g.fillStyle = "#f2f0ea";
  g.fillRect(14, 0, 12, 1024);
  g.fillRect(486, 0, 12, 1024);
  g.fillStyle = "#f5c542";
  g.fillRect(250, 0, 12, 560);
  return finish(c);
}

export function curbTexture() {
  const [c, g] = canvas(64, 256);
  for (let i = 0; i < 4; i++) {
    g.fillStyle = i % 2 ? "#f4f1ea" : "#e0263a";
    g.fillRect(0, i * 64, 64, 64);
  }
  return finish(c);
}

export function checkerTexture(cols = 16, rows = 2) {
  const [c, g] = canvas(cols * 32, rows * 32);
  for (let y = 0; y < rows; y++)
    for (let x = 0; x < cols; x++) {
      g.fillStyle = (x + y) % 2 ? "#111111" : "#f4f4f4";
      g.fillRect(x * 32, y * 32, 32, 32);
    }
  const t = finish(c, false);
  t.magFilter = THREE.NearestFilter;
  return t;
}

export function bannerTexture(text: string, sub: string, accent: string) {
  const [c, g] = canvas(2048, 256);
  const grad = g.createLinearGradient(0, 0, 2048, 0);
  grad.addColorStop(0, "#14101f");
  grad.addColorStop(0.5, "#22183a");
  grad.addColorStop(1, "#14101f");
  g.fillStyle = grad;
  g.fillRect(0, 0, 2048, 256);
  // checker strips top & bottom
  for (let x = 0; x < 2048 / 24; x++)
    for (let y = 0; y < 2; y++) {
      g.fillStyle = (x + y) % 2 ? "#111" : "#f4f4f4";
      g.fillRect(x * 24, y * 12, 24, 12);
      g.fillRect(x * 24, 232 + y * 12, 24, 12);
    }
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.font = "italic 800 128px 'Barlow Condensed', 'Arial Narrow', sans-serif";
  g.fillStyle = accent;
  g.fillText(text, 1024, 118);
  g.font = "italic 600 40px 'Barlow Condensed', 'Arial Narrow', sans-serif";
  g.fillStyle = "#f4efe6";
  g.fillText(sub, 1024, 196);
  return finish(c, false);
}

export function signTexture(text: string, accent: string) {
  const [c, g] = canvas(1024, 192);
  g.fillStyle = "#0e1622";
  g.fillRect(0, 0, 1024, 192);
  g.strokeStyle = accent;
  g.lineWidth = 10;
  g.strokeRect(8, 8, 1008, 176);
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.font = "italic 800 104px 'Barlow Condensed', 'Arial Narrow', sans-serif";
  g.fillStyle = accent;
  g.fillText(text, 512, 100);
  return finish(c, false);
}

/** Barrier wall face: dark panels with chevrons. */
export function barrierTexture() {
  const [c, g] = canvas(256, 64);
  g.fillStyle = "#1a1a24";
  g.fillRect(0, 0, 256, 64);
  g.fillStyle = "#262636";
  for (let i = 0; i < 4; i++) g.fillRect(i * 64 + 2, 4, 60, 56);
  g.fillStyle = "#3b3b52";
  for (let i = 0; i < 4; i++) {
    g.beginPath();
    g.moveTo(i * 64 + 18, 14);
    g.lineTo(i * 64 + 34, 32);
    g.lineTo(i * 64 + 18, 50);
    g.lineTo(i * 64 + 26, 50);
    g.lineTo(i * 64 + 42, 32);
    g.lineTo(i * 64 + 26, 14);
    g.fill();
  }
  return finish(c);
}

/** Soft round sprite for particles (alpha in all channels). */
export function softDotTexture() {
  const [c, g] = canvas(64, 64);
  const grad = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grad.addColorStop(0, "rgba(255,255,255,1)");
  grad.addColorStop(0.4, "rgba(255,255,255,0.6)");
  grad.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, 64, 64);
  return finish(c, false, false);
}

/** Sun glow sprite. */
export function sunTexture() {
  const [c, g] = canvas(256, 256);
  const grad = g.createRadialGradient(128, 128, 0, 128, 128, 128);
  grad.addColorStop(0, "rgba(255,250,235,1)");
  grad.addColorStop(0.12, "rgba(255,226,170,1)");
  grad.addColorStop(0.25, "rgba(255,160,90,0.55)");
  grad.addColorStop(0.6, "rgba(255,90,80,0.12)");
  grad.addColorStop(1, "rgba(255,80,80,0)");
  g.fillStyle = grad;
  g.fillRect(0, 0, 256, 256);
  return finish(c, false);
}
