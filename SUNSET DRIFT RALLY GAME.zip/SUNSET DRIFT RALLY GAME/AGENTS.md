<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Game architecture (Coastline Rush)

- Race rules, car physics, AI, skills and laps live in `src/game/sim/` as pure TypeScript (no React/three) so they stay unit-testable; scene components only draw world state.
- One stepper (`Stepper` in `src/game/scene/GameCanvas.tsx`, priority -10) advances input, the fixed-step (1/120 s) sim, events and audio before anything draws.
- Per-frame values stay in the world object; zustand (`src/game/store.ts`) holds only phase/popups/results, and the HUD polls the world at ~30 Hz.
- All audio is synthesized in `src/game/audio/AudioEngine.ts` (the brief forbids audio files).
- Road clearance lives in `TRACK` constants: `terrainHeight` returns a flat bed below y=0 inside `WALL + TERRAIN_CLEARANCE`, and prop placement subtracts each model's footprint radius before the `PROP_CLEARANCE` check, so nothing clips the road; tests in `sim.test.ts` guard it.
- Handbrake drift steers a target drift angle (not a yaw rate) and sets drift speed directly on the whole velocity, so slide control and speed don't depend on tyre scrub.
- Models are CC0 Kenney GLBs hosted via lovable-assets pointers in `src/assets/models/`; vegetation is instanced per GLB sub-mesh.
- Dev-only hooks: `window.__game` (`world`, `player`, `start()`, `sim(seconds)`, `audio()` levels) and `window.__fx` (toggle smoke/skid) for scripted checks; the canvas wrapper sets `data-scene-ready`.
