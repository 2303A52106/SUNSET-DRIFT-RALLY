// Client-side shared geometry data (distance field, prop placements). Built once, lazily.
import { TRACK } from "../sim/constants";
import { mulberry32 } from "../sim/math";
import { buildDistanceField, COAST_X, terrainHeight, type DistanceField } from "../sim/terrain";
import type { Track } from "../sim/track";
import { getTrack } from "../sim/world";

export interface PropItem {
  x: number;
  y: number;
  z: number;
  yaw: number;
  scale: number;
}

export interface WorldGeo {
  track: Track;
  field: DistanceField;
  palms: PropItem[][]; // per palm variant
  pines: PropItem[][];
  rocks: PropItem[][];
  /** sun direction (unit), low over the western sea */
  sunDir: [number, number, number];
}

/** Model heights (m) used by Vegetation for each pine / rock variant. */
export const PINE_HEIGHTS = [17, 12] as const;
export const ROCK_HEIGHTS = [5, 8] as const;

let geo: WorldGeo | null = null;

export function getWorldGeo(): WorldGeo {
  if (geo) return geo;
  const track = getTrack();
  const field = buildDistanceField(track);
  const rnd = mulberry32(1337);
  const h = (x: number, z: number) => terrainHeight(x, z, field);

  const palms: [PropItem[], PropItem[], PropItem[]] = [[], [], []];
  const pines: [PropItem[], PropItem[]] = [[], []];
  const rocks: [PropItem[], PropItem[]] = [[], []];
  const pick = <T,>(arr: T[], r: number) => arr[Math.min(arr.length - 1, Math.floor(r * arr.length))]!;

  // Palms line the coastal and southern sections
  track.samples.forEach((s, i) => {
    if (i % 5 !== 0) return;
    if (s.x > -60 && s.z > -330) return;
    for (const side of [-1, 1]) {
      if (rnd() < 0.25) continue;
      const lat = side * (TRACK.WALL + 4 + rnd() * 9);
      const x = s.x + s.rx * lat + (rnd() - 0.5) * 4;
      const z = s.z + s.rz * lat + (rnd() - 0.5) * 4;
      if (field.dist(x, z) < TRACK.WALL + 3) continue;
      pick(palms, rnd()).push({ x, y: h(x, z), z, yaw: rnd() * Math.PI * 2, scale: 0.85 + rnd() * 0.4 });
    }
  });
  // Beach palms between road and sea
  for (let i = 0; i < 70; i++) {
    const x = COAST_X + 40 + rnd() * 60;
    const z = -520 + rnd() * 1000;
    const y = h(x, z);
    if (y < -1 || field.dist(x, z) < TRACK.WALL + 5) continue;
    pick(palms, rnd()).push({ x, y, z, yaw: rnd() * Math.PI * 2, scale: 0.8 + rnd() * 0.5 });
  }
  // Pine forests and boulders in the mountains
  // Every rock and pine keeps its whole footprint PROP_CLEARANCE metres past the barrier.
  const minD = TRACK.WALL + TRACK.PROP_CLEARANCE;
  for (let i = 0; i < 3200 && pines[0].length + pines[1].length < 520; i++) {
    const x = -120 + rnd() * 760;
    const z = -620 + rnd() * 1240;
    const d = field.dist(x, z);
    const variant = rnd() < 0.6 ? 0 : 1;
    const scale = 0.75 + rnd() * 0.6;
    const radius = PINE_HEIGHTS[variant]! * scale * 0.28;
    if (d - radius < minD || d > 220) continue;
    const y = h(x, z);
    if (y > 95 || y < 0) continue;
    pines[variant]!.push({ x, y: y - 0.3, z, yaw: rnd() * Math.PI * 2, scale });
  }
  for (let i = 0; i < 900 && rocks[0].length + rocks[1].length < 90; i++) {
    const x = -200 + rnd() * 840;
    const z = -620 + rnd() * 1240;
    const d = field.dist(x, z);
    const variant = rnd() < 0.5 ? 0 : 1;
    const scale = 0.6 + rnd() * 1.4;
    // rock models are wide and flat: half-width ≈ 1.95× / 1.66× their height
    const radius = ROCK_HEIGHTS[variant]! * scale * (variant === 0 ? 1.95 : 1.66);
    if (d - radius < minD || d > 160) continue;
    const y = h(x, z);
    if (y < -0.5) continue;
    rocks[variant]!.push({ x, y: y - 0.6, z, yaw: rnd() * Math.PI * 2, scale });
  }

  const sd: [number, number, number] = [-0.93, 0.075, 0.36];
  const l = Math.hypot(sd[0], sd[1], sd[2]);
  geo = { track, field, palms, pines, rocks, sunDir: [sd[0] / l, sd[1] / l, sd[2] / l] };
  return geo;
}
