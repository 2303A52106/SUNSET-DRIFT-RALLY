# Model credits

All models are CC0 (public domain) by Kenney — https://kenney.nl

- Car Kit (race, race-future, sedan-sports, hatchback-sports) — https://kenney.nl/assets/car-kit — CC0
- Nature Kit (palms, pines, rocks) — https://kenney.nl/assets/nature-kit — CC0
