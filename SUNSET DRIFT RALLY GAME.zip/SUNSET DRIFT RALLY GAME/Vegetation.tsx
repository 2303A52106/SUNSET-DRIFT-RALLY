import { useGLTF } from "@react-three/drei";
import { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import palmTall from "@/assets/models/tree_palmTall.glb.asset.json";
import palmBend from "@/assets/models/tree_palmBend.glb.asset.json";
import palmDetailed from "@/assets/models/tree_palmDetailedTall.glb.asset.json";
import pineTall from "@/assets/models/tree_pineTallA.glb.asset.json";
import pineRound from "@/assets/models/tree_pineRoundC.glb.asset.json";
import rockA from "@/assets/models/rock_largeA.glb.asset.json";
import rockC from "@/assets/models/rock_largeC.glb.asset.json";
import { getWorldGeo, PINE_HEIGHTS, ROCK_HEIGHTS, type PropItem } from "./worldGeo";

const PALMS = [palmTall.url, palmBend.url, palmDetailed.url];
const PINES = [pineTall.url, pineRound.url];
const ROCKS = [rockA.url, rockC.url];
[...PALMS, ...PINES, ...ROCKS].forEach((u) => useGLTF.preload(u));

interface Part {
  geometry: THREE.BufferGeometry;
  material: THREE.Material;
  local: THREE.Matrix4;
}

/** Draws every placement of one GLB with one InstancedMesh per sub-mesh. */
function InstancedModel({ url, items, height, castShadow = false }: { url: string; items: PropItem[]; height: number; castShadow?: boolean }) {
  const gltf = useGLTF(url);
  const parts = useMemo<Part[]>(() => {
    const root = gltf.scene;
    root.updateMatrixWorld(true);
    const box = new THREE.Box3().setFromObject(root);
    const size = box.getSize(new THREE.Vector3());
    const s = height / Math.max(1e-3, size.y);
    const norm = new THREE.Matrix4()
      .makeScale(s, s, s)
      .multiply(new THREE.Matrix4().makeTranslation(-(box.min.x + box.max.x) / 2, -box.min.y, -(box.min.z + box.max.z) / 2));
    const out: Part[] = [];
    root.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (!mesh.isMesh) return;
      const src = mesh.material as THREE.MeshStandardMaterial;
      const material = src.clone();
      material.metalness = 0;
      material.roughness = 0.85;
      out.push({ geometry: mesh.geometry, material, local: norm.clone().multiply(mesh.matrixWorld) });
    });
    return out;
  }, [gltf, height]);
  if (!items.length) return null;
  return (
    <>
      {parts.map((p, i) => (
        <InstancedPart key={i} part={p} items={items} castShadow={castShadow} />
      ))}
    </>
  );
}

function InstancedPart({ part, items, castShadow }: { part: Part; items: PropItem[]; castShadow: boolean }) {
  const ref = useRef<THREE.InstancedMesh>(null);
  useLayoutEffect(() => {
    const mesh = ref.current;
    if (!mesh) return;
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const up = new THREE.Vector3(0, 1, 0);
    const p = new THREE.Vector3();
    const sc = new THREE.Vector3();
    items.forEach((it, i) => {
      q.setFromAxisAngle(up, it.yaw);
      m.compose(p.set(it.x, it.y, it.z), q, sc.setScalar(it.scale)).multiply(part.local);
      mesh.setMatrixAt(i, m);
    });
    mesh.instanceMatrix.needsUpdate = true;
    mesh.computeBoundingSphere();
  }, [items, part]);
  return <instancedMesh ref={ref} args={[part.geometry, part.material, items.length]} castShadow={castShadow} receiveShadow />;
}

export function Vegetation() {
  const geo = getWorldGeo();
  return (
    <group>
      {PALMS.map((u, i) => (
        <InstancedModel key={u} url={u} items={geo.palms[i] ?? []} height={12} castShadow />
      ))}
      {PINES.map((u, i) => (
        <InstancedModel key={u} url={u} items={geo.pines[i] ?? []} height={PINE_HEIGHTS[i] ?? 12} castShadow />
      ))}
      {ROCKS.map((u, i) => (
        <InstancedModel key={u} url={u} items={geo.rocks[i] ?? []} height={ROCK_HEIGHTS[i] ?? 6} />
      ))}
    </group>
  );
}
